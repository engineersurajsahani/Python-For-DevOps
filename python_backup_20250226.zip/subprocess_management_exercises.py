import subprocess
import threading
import time
import shlex
import sys
import os
from datetime import datetime

# Exercise 1: System health check script
def system_health_check():
    """Run system health checks using various shell commands."""
    print("SYSTEM HEALTH CHECK")
    print("===================")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Hostname: {os.uname().nodename}")
    print("===================\n")
    
    # Check disk space
    print("DISK SPACE:")
    try:
        result = subprocess.run(['df', '-h'], capture_output=True, text=True, check=True)
        print(result.stdout)
    except subprocess.SubprocessError as e:
        print(f"Error checking disk space: {str(e)}")
    
    # Check memory usage
    print("MEMORY USAGE:")
    try:
        if sys.platform == 'linux' or sys.platform == 'darwin':
            if sys.platform == 'linux':
                result = subprocess.run(['free', '-h'], capture_output=True, text=True, check=True)
            else:  # Darwin (macOS)
                result = subprocess.run(['vm_stat'], capture_output=True, text=True, check=True)
            print(result.stdout)
        elif sys.platform == 'win32':
            result = subprocess.run(['tasklist'], capture_output=True, text=True, check=True)
            print(result.stdout)
    except subprocess.SubprocessError as e:
        print(f"Error checking memory usage: {str(e)}")
    
    # Check CPU load
    print("CPU LOAD:")
    try:
        if sys.platform == 'linux':
            result = subprocess.run(['uptime'], capture_output=True, text=True, check=True)
            print(result.stdout)
            
            # More detailed CPU info
            result = subprocess.run(['top', '-bn1', '|', 'grep', 'Cpu'], 
                                  shell=True, capture_output=True, text=True)
            print(result.stdout)
        elif sys.platform == 'darwin':  # macOS
            result = subprocess.run(['sysctl', '-n', 'vm.loadavg'], 
                                  capture_output=True, text=True, check=True)
            print(f"Load Average: {result.stdout}")
        elif sys.platform == 'win32':
            result = subprocess.run(['wmic', 'cpu', 'get', 'loadpercentage'], 
                                  capture_output=True, text=True, check=True)
            print(result.stdout)
    except subprocess.SubprocessError as e:
        print(f"Error checking CPU load: {str(e)}")
    
    # Check running processes
    print("TOP PROCESSES:")
    try:
        if sys.platform == 'linux':
            result = subprocess.run(['ps', 'aux', '--sort=-%cpu', '|', 'head', '-10'], 
                                  shell=True, capture_output=True, text=True)
            print(result.stdout)
        elif sys.platform == 'darwin':  # macOS
            result = subprocess.run(['ps', '-Ao', 'pid,comm,%cpu', '--sort=-%cpu', '|', 'head', '-10'], 
                                  shell=True, capture_output=True, text=True)
            print(result.stdout)
        elif sys.platform == 'win32':
            result = subprocess.run(['tasklist', '/v', '/fi', 'STATUS eq running'], 
                                  capture_output=True, text=True, check=True)
            print(result.stdout[:500])  # Limit output
    except subprocess.SubprocessError as e:
        print(f"Error checking running processes: {str(e)}")
    
    print("\nHEALTH CHECK COMPLETE")

# Example usage
if __name__ == "__main__":
    # Run system health check
    system_health_check()
    